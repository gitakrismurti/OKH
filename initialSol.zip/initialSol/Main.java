import java.util.Scanner;


/**
 * 
 * @author Muris
 * Simulasi Timetabling
 * 
 * modified by riski & gita okh 2020
 */

public class Main {
	
	static final String DIREKTORI = "D:/KULIAH/Semester 6/OKH/FP/toronto/";
	public static String course = "";
	public static String student = "";
	
	public static void main(final String[] args) {
		

		final String carf92_stu = DIREKTORI + "car-f-92.stu";
		final String carf92_crs = DIREKTORI + "car-f-92.crs";

		final String cars91_stu = DIREKTORI + "car-s-91.stu";
		final String cars91_crs = DIREKTORI + "car-s-91.crs";

		final String earf83_stu = DIREKTORI + "ear-f-83.stu";
		final String earf83_crs = DIREKTORI + "ear-f-83.crs";

		final String hecs92_stu = DIREKTORI + "hec-s-92.stu";
		final String hecs92_crs = DIREKTORI + "hec-s-92.crs";

		final String kfus93_stu = DIREKTORI + "kfu-s-93.stu";
		final String kfus93_crs = DIREKTORI + "kfu-s-93.crs";

		final String lsef91_stu = DIREKTORI + "lse-f-91.stu";
		final String lsef91_crs = DIREKTORI + "lse-f-91.crs";

		final String purs93_stu = DIREKTORI + "pur-s-93.stu";
		final String purs93_crs = DIREKTORI + "pur-s-93.crs";

		final String ryes93_stu = DIREKTORI + "rye-s-93.stu";
		final String ryes93_crs = DIREKTORI + "rye-s-93.crs";

		final String staf83_stu = DIREKTORI + "sta-f-83.stu";
		final String staf83_crs = DIREKTORI + "sta-f-83.crs";

		final String tres92_stu = DIREKTORI + "tre-s-92.stu";
		final String tres92_crs = DIREKTORI + "tre-s-92.crs";

		final String utas92_stu = DIREKTORI + "uta-s-92.stu";
		final String utas92_crs = DIREKTORI + "uta-s-92.crs";

		final String utes92_stu = DIREKTORI + "ute-s-92.stu";
		final String utes92_crs = DIREKTORI + "ute-s-92.crs";

		final String yorf83_stu = DIREKTORI + "yor-f-83.stu";
		final String yorf83_crs = DIREKTORI + "yor-f-83.crs";

		System.out.println("1. Car-f-92");
		System.out.println("2. Car-s-91");
		System.out.println("3. Ear-f-83");
		System.out.println("4. Hec-s-92");
		System.out.println("5. Kfu-s-93");
		System.out.println("6. Lse-f-91");
		System.out.println("7. Pur-s-93");
		System.out.println("8. Rye-s-93");
		System.out.println("9. Sta-f-83");
		System.out.println("10. Tre-s-92");
		System.out.println("11. Uta-s-92");
		System.out.println("12. Ute-s-92");
		System.out.println("13. yor-f-83");
		System.out.println("99. EXIT");
		System.out.print("Pilih dataset : \n");

		final Scanner input = new Scanner(System.in);
		final int dataset = input.nextInt();

		switch (dataset) {
			case 1:
				student = carf92_stu;
				course  = carf92_crs;
				break;
			case 2:
				student = cars91_stu;
				course  = cars91_crs;
				break;
			case 3:
				student = earf83_stu;
				course  = earf83_crs;
				break;
			case 4:
				student = hecs92_stu;
				course  = hecs92_crs;
				break;
			case 5:
				student = kfus93_stu;
				course  = kfus93_crs;
				break;
			case 6:
				student = lsef91_stu;
				course  = lsef91_crs;
				break;
			case 7:
				student = purs93_stu;
				course  = purs93_crs;
				break;
			case 8:
				student = ryes93_stu;
				course  = ryes93_crs;
				break;
			case 9:
				student = staf83_stu;
				course  = staf83_crs;
				break;
			case 10:
				student = tres92_stu;
				course  = tres92_crs;
				break;
			case 11:
				student = utas92_stu;
				course  = utas92_crs;
				break;
			case 12:
				student = utes92_stu;
				course  = utes92_crs;
				break;
			case 13:
				student = yorf83_stu;
				course  = yorf83_crs;
				break;
		}

		double startTime = System.nanoTime();
		
		final CourseSet cs = new CourseSet(course);
		final ConflictMatrix cm = new ConflictMatrix(student, cs.getSize());
		final int[][] confMat = cm.getConflictMatrix();
		final int jumlahSiswa = cm.getJumlahStudent();
		final int[][] solution = Scheduler.getSaturationSchedule(cs.getSize(), cm.getDegree(), confMat);
		final Solution bestSolution = new Solution(solution);
		System.out.println("Jumlah Timeslot : " + bestSolution.getJumlahTimeslot());
		System.out.println("Penalty : " + Utils.getPenalty(confMat, solution, jumlahSiswa));
		
		double endTime = System.nanoTime();
		double duration = (endTime - startTime) / 1000000000;
		System.out.println("Execution Time : " + duration);

	}
}