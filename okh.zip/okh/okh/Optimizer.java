package okh;
import okh.Utils;

public class Optimizer {
	private static int[][] jadwalTheBest;
	
	private static void setJadwal(final int[][] jadwal) {
		jadwalTheBest = jadwal;
	}
	
	public static int[][] getJadwal() {
		return jadwalTheBest;
	}
	
	public static void randomSearch(final String student, final String course, final int timeslot) {
		final CourseSet cs = new CourseSet(course);
		final ConflictMatrix cm = new ConflictMatrix(student, cs.getSize());
		
		final int [][] copyGraph = Utils.copyArray(cm.getConflictMatrix());
		final int [][] graph = cm.getRandomMatrix();
		
		final int jumlahTimeslot = timeslot;
		final Scheduler scheduler = new Scheduler(cs.getSize());
		scheduler.timesloting(graph, jumlahTimeslot);
		
		scheduler.printSchedule(cm.getRandomIndex(graph.length));
		final int jumlah = cm.getJumlahStudent();
		final int[][] jadwal = scheduler.getSchedule();
		
		final int[][] gr = cm.getLargestDegree(copyGraph);
		
		double penalty = Utils.getPenalty(gr, jadwal, jumlah);
		System.out.println(penalty);
		for(int i = 0; i < 1000; i++) {
			final CourseSet csIter = new CourseSet(course);
			final ConflictMatrix cmIter = new ConflictMatrix(student, cs.getSize());
			
			final int [][] copyGraphIter = Utils.copyArray(cmIter.getConflictMatrix());
			final int [][] graphIter = cm.getRandomMatrix();
			
			final Scheduler schedulerIter = new Scheduler(csIter.getSize());
			
			schedulerIter.timesloting(graphIter, jumlahTimeslot);
			schedulerIter.printSchedule(cm.getRandomIndex(graphIter.length));
			final int[][] jadwalIter = schedulerIter.getSchedule();
			
			final int[][] grIter = cm.getLargestDegree(copyGraphIter);
			
			final double penalty2 = Utils.getPenalty(grIter, jadwalIter, jumlah);
			
			if(penalty > penalty2)
				penalty = penalty2;
			
			System.out.println("Iterasi "+(i+1)+" - Penalty : "+penalty);
		}
	}
	
	public static void hillClimbing(final String student, final String course, final int timeslot, final int iterasi) {
		final CourseSet cs = new CourseSet(course);
		final ConflictMatrix cm = new ConflictMatrix(student, cs.getSize());
		
		final int [][] conflict_matrix = cm.getConflictMatrix();
		final int[][] jadwal = Scheduler.getSaturationSchedule(cs.getSize(), cm.getDegree(), conflict_matrix);
		
		final int jumlahStudent = cm.getJumlahStudent();
		
		final int[][] jadwalTemp = new int[jadwal.length][2];
		
		for(int i = 0; i < jadwalTemp.length; i++) {
			jadwalTemp[i][0] = jadwal[i][0];
			jadwalTemp[i][1] = jadwal[i][1];
		}
		
		double penalty = Utils.getPenalty(conflict_matrix, jadwal, jumlahStudent);
		
		final Solution bestSolution = new Solution(jadwal);
		final int max_timeslot = bestSolution.getJumlahTimeslot();
		
		for(int i = 0; i < iterasi; i++) {			
			final int randomCourseIndex = Utils.getRandomNumber(0, conflict_matrix.length-1);
			final int randomTimeslot = Utils.getRandomNumber(0, max_timeslot-1);
		
			if (Scheduler.checkRandomTimeslot(randomCourseIndex, randomTimeslot, conflict_matrix, jadwalTemp)) {	
				jadwalTemp[randomCourseIndex][1] = randomTimeslot;
				final double penalty2 = Utils.getPenalty(conflict_matrix, jadwalTemp, jumlahStudent);
				
				if(penalty > penalty2) {
					penalty = Utils.getPenalty(conflict_matrix, jadwalTemp, jumlahStudent);
					jadwal[randomCourseIndex][1] = jadwalTemp[randomCourseIndex][1];
					bestSolution.setSolution(jadwal);
					bestSolution.setPenalty(penalty);
				} else {
					jadwalTemp[randomCourseIndex][1] = jadwal[randomCourseIndex][1];
				}
			}
		}
		
		setJadwal(jadwal);
		System.out.println(bestSolution.getPenalty());
	}	
}
